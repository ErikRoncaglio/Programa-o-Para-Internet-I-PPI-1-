<form action="http://localhost/teste.php">
    Nome:<input id="idname" type="text" name="varA" value=<?php
    if (isset($_GET["varA"])) {
        echo $_GET["varA"];
    }
    ?>>
    <br><br>
    Idade: <input id="ididade" type="text" name="varB" value=<?php
    if (isset($_GET["varB"])) {
        echo $_GET["varB"];
    }
    ?>>
    
<br><br>
    <input type="submit" value="Salvar">
</form>