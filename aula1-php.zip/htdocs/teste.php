<?php
if ((isset($_GET["varA"])) && (isset($_GET["varB"]))) {
    $a = $_GET["varA"];
    $b = $_GET["varB"];
    echo "Nome: " . $a;
    
    echo "<br>Idade: " . $b;
}

?>
<form action="http://localhost/imc.php?">


    <input id="idname" type="text" name="varA"  hidden value=<?php
   
        echo $_GET["varA"];
    
    ?> >
     <input id="ididade" type="text" name="varB" hidden value=<?php
   
   echo $_GET["varB"];

?>> 



Peso: <input id="idpeso" type="text" name="varC" value=<?php
    if (isset($_GET["varC"])) {
        echo $_GET["varC"];
    }
    ?>>
    <br><br>
    Altura:<input id="idAltura" type="text" name="varD" value=<?php
    if (isset($_GET["varD"])) {
        echo $_GET["varD"];
    }
    ?>>
    <br><br>
        <input type="submit" value="Salvar">
</form>