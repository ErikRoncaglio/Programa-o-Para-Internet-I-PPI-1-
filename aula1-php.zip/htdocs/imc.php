<?php
/*if ((isset($_GET["varA"])) && (isset($_GET["varB"])) && (isset($_GET["varC"])) && (isset($_GET["varD"]))) {*/
    $a = $_GET["varA"];
    $b = $_GET["varB"];
    $c = $_GET["varC"];
    $d = $_GET["varD"];
    echo "<br>Nome: ".$a;
    
    echo "<br>Idade: ".$b;
    echo "<br>Altura: ".$c;
    echo "<br>Peso: ".$d;
    echo "<br>IMC: ".($c*$c)/$d;


?>